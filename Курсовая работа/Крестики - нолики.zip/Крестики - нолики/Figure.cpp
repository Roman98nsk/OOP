#include "Figure.h"

Figure::~Figure()
{
}
