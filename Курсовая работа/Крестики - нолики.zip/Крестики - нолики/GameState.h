#pragma once
enum class GameState
{
	MENU, RUN, ANIM
};

