#include <iostream>
#include "point.h"
#include "gfx.h"
#include "UI.h"

using namespace std;

int main(){
    Point a[COUNT];
    show_screen(a);
    return 0;
}