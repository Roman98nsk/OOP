#ifndef UI_H
#define UI_H
#include "point.h"

#define YSCREEN 600
#define XSCREEN 800

void show_screen(Point* points);
void create_point(Point point);

#endif